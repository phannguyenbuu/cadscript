﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Drawing;
using System.Threading.Tasks;

namespace AcadScript
{
    public class gDraw2DDCLS
    {
        public cReadData CssData { get; set; }

        public gDraw2DDCLS(cReadData css)
        {
            CssData = css;
        }

        void AppendHtml(string st)
        {
            CssData.html_contents.Add(st);
        }

        public double pX(pPos pt)
        {
            return (pt.X - CssData.html_basepoint.X).roundNumber(0.01) * CssData.drawing_scale;
        }

        public double pY(pPos pt)
        {
            return (CssData.html_basepoint.Y - pt.Y).roundNumber(0.01) * CssData.drawing_scale;
        }

        public void AppendCircleHtml(pPos pt, double r, string style = "")
        {
            AppendHtml(String.Format("<circle cx='{0}' cy='{1}' r='{2}' {3}/>",
                pX(pt), pY(pt), r, style.et_() ? "" : "style='" + style + "'"));
        }

        public void AppendTextHtml(string content, pPos pt, string ext = "", double rotation = 0)
        {
            //string color = style._prop("color");
            //string align = "middle";
            //string valign = "central";
            
            if(rotation == 0)
                AppendHtml(String.Format("<text x='{0}' y='{1}' {3}>{2}</text>",
                    pX(pt), pY(pt), content, ext));
            else
                AppendHtml(String.Format("<text x='{0}' y='{1}' {3} transform='rotate({4},{0},{1})'>{2}</text>",
                    pX(pt), pY(pt), content, ext, rotation));
        }

        public void AppendPolylineHtml(IEnumerable<pPos> pts, bool closed = true, string style = "")
        {
            AppendHtml("<" + (closed ? "polygon" : "polyline") + " points='"
                + pts.Select(pt => pX(pt) + "," + pY(pt)).ToTextStr(" ") + "'"

                + style
                
                + "/>");

            foreach (pPos[] seg in pts.GetSegment(closed))
            {
                List<pPos> r = seg[0].Parallel(seg[1], CssData.wall_shape_width / 2).ToList();
                r.AddRange(seg[0].Parallel(seg[1], - CssData.wall_shape_width / 2).Reverse());

                CssData.wall_html_contents.Add("<" + (closed ? "polygon" : "polyline") + " points='"
                    + r.Select(pt => pX(pt) + "," + pY(pt)).ToTextStr(" ") + "'"

                    + " style='fill:red; fill-opacity:0.5'" 
                    + "/>");
            }

        }
    }

}
