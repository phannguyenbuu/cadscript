﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Drawing;
using System.IO;

namespace AcadScript
{
    public class gDraw2DPolygonCLS : gDraw2DDCLS
    {
        public gDraw2DPolygonCLS(cReadData css) : base(css) { }
        double txt_spacing = 8;
        bool _area_in_cirle_mode = true;
        double circle_size = 2.8;

        double _rounN(double v, params double[] base_rounds)
        {
            double res = v;

            for(int i = 0; i < base_rounds.Length - 1; i++)
                if (v < base_rounds[i + 1] && v > base_rounds[i])
                {
                    double a = base_rounds[i + 1] - v;
                    double b = v - base_rounds[i];
                    
                    if (a < b)
                        res = base_rounds[i + 1];
                    else
                        res = base_rounds[i];

                    break;
                }

            return res.roundNumber(0.01);
        }

        pPos _get_txt_area_offset(pPos[] pts)
        {
            double angle = _rounAngle(CSVDataCLS._getRegionAngle(pts));
            pPos sz = CSVDataCLS._getRegionSize(pts);

            return new pPos(Math.Abs(Math.Cos(angle / 180 * Math.PI)), 
                Math.Abs(Math.Sin(angle / 180 * Math.PI)))

                * txt_spacing;
        }

        double _rounAngle(double __ang)
        {
            if (__ang == 180) __ang = 0;
            if (__ang == 90) __ang = 270;

            double a = Math.Sin(__ang / 180 * Math.PI);
            double b = Math.Cos(__ang / 180 * Math.PI);

            if (Math.Abs(a) < Math.Abs(b))
                __ang = 0;
            else
                __ang = 270;

            return __ang;
        }

        public void DrawPolygonItem(pPos[] pts, pPos pt_title, int counter = 0)
        {
            double angle = CSVDataCLS._getRegionAngle(pts);
            
            string s_caption = CssData.CaptionList._props(pt_title.Content);
            
            if (s_caption.et_())
                s_caption = pt_title.Content;

            string s_area = CssData.AreaList._props(pt_title.Content);
            //double circle_size = (float)(CssData.AllXNotes._props("Show.Circle").ToNumber(30) * CssData.drawing_scale);
            circle_size *= CssData.drawing_scale;

            if (angle == -999)
                angle = (float)pt_title.Rotation;
                
            double v = 8.0f
                + (CssData.AllXNotes._props("Show.zigzag").ToBool()
                ? (counter % 2 == 0 ? 0 : -5) : -2);
                
            double area = (pts.Area()).roundNumber(0.01);

            if (s_area.empty())
            {
                s_area = "" + _rounN(area, 80, 100, 120, 150, 180, 200, 220, 250, 
                    280, 300, 320, 360, 380, 400, 420, 450, 480, 500, 1000);
            }

            v += (s_caption.Length > 2 || area > 999 ? 7f : 3.5f) ;

            angle = Math.Round((angle + 180) % 360);

            if (angle == 270) angle = 90;
            if (angle == 360) angle = 0;

            string id = "txt_" 
                + new string(s_caption.Replace("3A","").Replace("2A", "").Replace("2B","")
                .Where(c => !"01234567890".Contains(c)).ToArray()) + "_" + angle;

            double x = 0, y = 0;

            if (angle == 0)
            {
                x = 35;
                y = 0;
            }
            else if (angle == 90)
            {
                x = -35;
                y = 10;
            }

            CssData.AddHtmlCss("div#" + id, false, "transform-origin:center center",
                "transform: " + "rotate(" + angle + "deg)" + " translate(" + x  + "px," + y + "px)");

            x = 0;
            y = 0;

            CssData.AddHtmlCss("div#title", false,
                "font-weight: bold", "text-align: center", "transform: translate("+ x + "px, " + y + "px)");

            bool show_road_mode = new string[]{
                    "CÔNG VIÊN", "CAFE", "NHÀ HÀNG", "TRUNG TÂM",
                    "GRASS","WATER","PAVE", "ROAD", "WALK", "LAND"}
                .Any(__s => s_caption.ct_(__s));

            if(!show_road_mode)
            {
                AppendCircleHtml(pt_title, circle_size, "stroke:black;fill:white");

                if (_area_in_cirle_mode)
                {
                    AppendTextHtml(s_caption, pt_title + new pPos(0, 1.25 * CssData.drawing_scale), "fill='red' font-size='2'");
                    AppendPolylineHtml(new pPos[] { pt_title - new pPos(circle_size, 0), pt_title + new pPos(circle_size, 0) }, 
                        false, " style='stroke-opacity:1;fill:none'");
                }
                else
                    AppendTextHtml(s_caption, pt_title, "fill='red' font-size='2'");
            }

            if (show_road_mode)
            {
                if (pt_title.Content.ct_("WALK"))
                {
                    if (pts[0].DistanceToPoint(pts[1]) > pts[0].DistanceToPoint(pts[3]))
                        _drawDimension(pts[0], pts[1], "white");
                    else
                        _drawDimension(pts[0], pts[3], "white");
                }
            }
            else
            {
                for (int i = 0; i < pts.Length; i++)
                    _drawDimension(pts[i], pts[i == pts.Length - 1 ? 0 : i + 1]);
            }

            if (!show_road_mode && (CssData.AllXNotes._props("Show.Area").et_()
                || CssData.AllXNotes._props("Show.Area").ToBool()))
            {
                if (_area_in_cirle_mode)
                    AppendTextHtml(s_area, pt_title - new pPos(0, 1.25 * CssData.drawing_scale), "fill='black'");
                else
                    AppendTextHtml(s_area, pt_title + _get_txt_area_offset(pts), "fill='black'", _rounAngle(angle));
            }
        }

        void _drawDimension(pPos p1, pPos p2, string color = "grey")
        {
            double dist = p1.DistanceTo(p2).roundNumber(1);

            if(dist > 3)
            {
                pPos ct = ((p1 + p2) / 2).Round(1);

                AppendTextHtml(dist + "m", ct, "fill='" + color + "' font-size='2.5'", 
                    _rounAngle(Math.Abs((p2 - p1).Angle().roundNumber())));
                AppendCircleHtml(p1, 0.5, "fill:" + color);
                AppendCircleHtml(p2, 0.5, "fill:" + color);
            }
        }
    }
 
}
