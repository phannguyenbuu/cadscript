﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;

using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.Runtime;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.Colors;
using Autodesk.AutoCAD.Internal;


using System.Windows.Forms;
//using SyncObject;

namespace AcadScript
{
    public class cReadData
    {
        public double min, round;
        public float fence_spacing, fence_min, fence_size;


        public double wall_shape_width = 0.1;

        //public float canvas_scale = 8.5f, canvas_offset = 50f;
        public pPos basept, html_basepoint;
        public List<string> html_contents;
        public List<string> wall_html_contents;

        public List<pPos> inblock_titles;

        public int H = 1000, W = 1000;
        public string dim_block_key, showmode;
        public string script_dir = @"D:\Dropbox\VS Projects\ScriptEditor\Sample\System\";
        public string drawing_title_suffix = "", drawing_title_prefix = "";
        public double drawing_scale = 1, drawing_title_size = 1, drawing_number_size = 1, drawing_angle = -999;
        public pPos[] TitleList, bb;
        public string[] AreaList, CaptionList, AllXNotes, ItemNoteList, Region3DInforList, Material3DList, Modifier3DList;
        public double[] PriceList, ThoCuList;
        public int drawing_axis = -1;

        public string project_name;
        public double price_offset;
        public CSVDataCLS csv;

        public string path_sample_tree = @"D:\Dropbox\3DLib\maps\sk\Tree plan\SampleTree.png";
        public float tree_size = 3f;

        public string exp_dir = @"D:\$exp";
        public pPos size, drawing_title_offset;
        public static double __sc = 1;
        public List<string> HtmlCssList;

        public static string _getCrossRoadMtlAxis(pPos[] ls)
        {
            double __ang = CSVDataCLS._getRegionAngle(ls);

            string res = "";
            double a = Math.Sin(__ang / 180 * Math.PI);
            double b = Math.Cos(__ang / 180 * Math.PI);

            if (Math.Abs(a) < Math.Abs(b))
                res = "MT_WALK_1";
            else
                res = "MT_WALK_2";

            return res;
        }

        public static pPos[] _getMLineVertices(ObjectId _id)
        {
            ObjectIdCollection _newIds = ACD.DB.ExplodeEntity(_id);

            List<pPos> _lls = new List<pPos>();
            //int i = 0;
            for(int i = 0; i < _newIds.Count - 1; i += 2)
            {
                _lls.AddRange(ACD.DB._getVertices(_newIds[i], 0, false));
                _lls.AddRange(ACD.DB._getVertices(_newIds[i + 1], 0, false).Reverse());
            }

            _lls.Add(_lls[0]);

            ACD.DB.EraseObjects(_newIds);

            return _lls.ToArray();
        }

        public char[] AllNameLetters
        {
            get
            {
                return "ABCDEFGHIJK".Select(s => s).ToArray();
            }
        }

        public string GetHtmlCodeFromBlockPt(pPos blockpt)
        {
            return String.Format("<div id='{0}' insert='{1}'>",
                    Path.GetFileNameWithoutExtension(ACD.CurrentDWGFileName) + "_" + blockpt.Content,
                    blockpt.X.roundNumber(0.01) + "," + blockpt.Y.roundNumber(0.01));
        }

        public pPos GetRegionTitle(pPos[] pts, bool closed, out string st)
        {
            pPos p = pts.FirstOrDefault(p1 => !p1.Content.empty());
            pPos res = TitleList.FirstOrDefault(p1 => p1.Inside(pts));

            //ACD.WR("REGION {0} PTS {1}", res, pts.ToText());

            string title = res == null ? "" : res.Content;
            
            st = p == null ? "" : (p.Content
                + (title.empty() ? "" : "(" + title + ")") + "=" + pts.ToText(closed));
            //ACD.WR("oK5");
            if (res == null)
                res = pts.Centroid();

            res.Content = title;

            //ACD.WR("<Polygon title> {0} TitleList {1} Content {2}", title, TitleList.Length, res);

            return res;
        }

        pPos[] _searchBlockByName(string key)
        {
            string[] blocknames = ACD.DB.ListBlock().Where(s => s.ct_(key)).ToArray();

            List<pPos> res = new List<pPos>();

            ACD.DB.GetEntities(null, EN_SELECT.AC_DXF, "INSERT");

            foreach (ObjectId id in IR.SelectedIds)
                if (blocknames.Contains(ACD.DB._getIdName(id)))
                    ACD.DB.BlockEntitiesAction(id, (subIds) =>
                    {
                        res.AddRange(subIds.ToList()
                                .Where(sid => ACD.DB._isText(sid))
                                .Select(sid =>
                                {
                                    pPos p = ACD.DB._getPoint(sid);
                                    p.Rotation = ACD.DB._getRotation(sid);
                                    return p;
                                }
                            )
                        );
                    });

            ACD.WR("<TitleList> Blocks {0} result {1}", blocknames.Length, res.Count);
            return res.ToArray();
        }


        public static string DefaultHtmlCss (double drw_scale)
        {
            string content = "<head>\r\n"
                   + "\t<link rel = 'stylesheet' href = 'styles/planstyle.css'>\r\n"
                   + "</head>\r\n\r\n";

            

            return content;
        }

        public string AddHtmlCss(string cssname, bool add_transform, params string[] cssvalues)
        {
            string css = "\t" + cssname + "\r\n\t{\r\n\t\t" + cssvalues.ToTextStr(";\r\n\t\t") 
                + (add_transform ? "\t\ttransform: translate(0,0);" : "") + "}\r\n";

            if (!HtmlCssList.Contains(css))
                HtmlCssList.Add(css);

            return cssname;
        }

        public static string DefaultXNotes
        {
            get
            {
                return File.ReadAllText(Path.Combine(DE.CADLIB_CONSTRUCT, "DefautCSSData.txt"));
            }
        }

        public string[] StyleList;

        void _readAllConfig()
        {
            drawing_scale = AllXNotes._props("Drawing.Scale").ToNumber(drawing_scale);
            //canvas_scale = (float)AllXNotes._props("Canvas.Scale").ToNumber(1);
            drawing_title_suffix = AllXNotes._props("Show.Title.Suffix");

            string val = AllXNotes._props("Show.Title.Offset");

            drawing_title_offset = new pPos(0, 0);
            if (!val.et_())
                drawing_title_offset = pPos.FromString(val);

            drawing_title_prefix = AllXNotes._props("Show.Title.Prefix");
            drawing_title_size = (float)AllXNotes._props("Show.Title").ToNumber(1);
            drawing_number_size = (float)AllXNotes._props("Show.Number").ToNumber(1);
            price_offset = AllXNotes._props("Price.Offset").ToNumber(0);
            project_name = AllXNotes._props("Project.Name");

            min = AllXNotes._props("Region.Min").ToNumber();
            round = AllXNotes._props("Region.Round").ToNumber();
            fence_spacing = (float)AllXNotes._props("Fence.Spacing").ToNumber(10);
            fence_min = (float)AllXNotes._props("Fence.Min").ToNumber(5);
            fence_size = (float)AllXNotes._props("Fence.Size").ToNumber(2);

            //ACD.WR("AC0");

            showmode = AllXNotes._props("Show").Upper();

            string st = AllXNotes._props("Drawing.Angle");

            if (!st.empty())
            {
                string[] ar = st.filter(", ");
                drawing_angle = ar[0].ToNumber(-999);

                if (ar.Length > 1)
                    drawing_axis = (int)ar[1].ToNumber();
            }

            dim_block_key = AllXNotes._props("Title");
            
            //ACD.WR("AC1");
            AreaList = AllXNotes.Where(s => s.StartsWith("Area.")).Select(s => s.Replace("Area.", "")).ToArray();
            CaptionList = AllXNotes.Where(s => s.StartsWith("Caption.")).Select(s => s.Replace("Caption.", "")).ToArray();
            PriceList = new double[AreaList.Length];
            ThoCuList = new double[AreaList.Length];
            ItemNoteList = new string[AreaList.Length];

            double price = 0, thocu = 0;
            string note = "";

            //ACD.WR("AC2");

            for (int i = 0; i < AreaList.Length; i++)
            {
                string[] ar = AreaList[i].filter(" ");

                foreach (string s in ar)
                    if (s.StartsWith("TC"))
                    {
                        thocu = s.Replace("TC", "").ToNumber();
                    }
                    else if (s.StartsWith("$"))
                    {
                        price = s.Replace("$", "").ToNumber() * 1000000;
                    }
                    else if (s.StartsWith("@") || s.StartsWith("#"))
                    {
                        note = s.Substring(1);
                    }

                AreaList[i] = ar[0];
                PriceList[i] = price;
                ThoCuList[i] = thocu;
                ItemNoteList[i] = note;
            }

            //ACD.WR("AC3");

            if (!dim_block_key.et_())
                TitleList = _searchBlockByName(dim_block_key);


            StyleList = AllXNotes.Where(s => s.st_("style_")).Select(s => s).ToArray();

            //ACD.WR("StyleList {0}", StyleList.ToTextStr(";"));

            //ACD.WR("AC4");
        }
          
        public cReadData(ObjectIdCollection selIds)
        {
            HtmlCssList = new List<string>();
            html_contents = new List<string>();
            wall_html_contents = new List<string>();
            inblock_titles = new List<pPos>();

            Region3DInforList = new string[0];
            Material3DList = new string[0];
            Modifier3DList = new string[0];
            TitleList = new pPos[0];

            AllXNotes = ACD.AllSelectionXNotes;

            if (AllXNotes == null || AllXNotes.Length == 0 || AllXNotes.ToTextStr("").Upper().empty())
            {
                ACD.DB.SetXNotes(selIds.First(), DefaultXNotes);
                AllXNotes = DefaultXNotes.filter("\r\n");
            }

            _readAllConfig();

            Directory.CreateDirectory(exp_dir);

            foreach (string f in Directory.GetFiles(exp_dir, "*.*"))
                File.Delete(f);

            bb = ACD.DB._getBound(selIds);

            size = bb.Size();
            basept = bb[0];

            W = (int)size.X;
            H = (int)size.Y;

            //ACD.WR("Drawing.Scale {0}", drawing_scale);
        }
    }
}

