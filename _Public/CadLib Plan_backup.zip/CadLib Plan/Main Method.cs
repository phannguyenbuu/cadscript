﻿using System.Drawing;
using System;
using System.Globalization;
using System.Collections.Generic;
using System.Linq;
using System.IO;

using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.Runtime;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.Colors;
using Autodesk.AutoCAD.Internal;


using System.Windows.Forms;
//using SyncObject;
//using Photoshop;

namespace AcadScript
{
    public class CadLibPlanCLS
    {

        static void _addCircle(ObjectId id)
        {
            pPos ct = ACD.DB._getPoint(id);
            double r = ACD.DB._getRadius(id);

            var pt = CssData.inblock_titles.FirstOrDefault(p => p.DistanceTo(ct) <= r);

            region2d.AppendCircleHtml(ct, r * CssData.drawing_scale, 
                _getStylename( pt != null ? pt.Content : null, "stroke:black;opacity:0.5"));
        }

        static string _getStylename(string key, string _default = null)
        {
            string stylename = null;

            if (!key.et_())
                stylename = CssData.StyleList.FirstOrDefault(s => s.st_("style_" + key));

            //ACD.WR("StyleItem {0},{1}", key, stylename);

            return stylename.et_() ? 
                (_default.et_() ? null : " style='" + _default + "'")
                : " style='" + stylename._firstProp() + "'";
        }

        static PosCollection _idsToPts(ObjectIdCollection ids, int segments = 32)
        {
            PosCollection res = new PosCollection();
            res.Closed = new bool[0];

            //ACD.WR("I01");

            foreach (ObjectId id in ids)
                if (ACD.DB._isPolyline(id) && ACD.DB._getLayer(id).Upper() != "DEFPOINTS")
                {
                    //ACD.WR("I02");
                    res.Add(ACD.DB._getVertices(id, segments));
                    //ACD.WR("I02.1");
                    res.Closed = res.Closed.Add(ACD.DB._isPolylineClosed(id));
                    //ACD.WR("I02.2");
                    region2d.AppendPolylineHtml(ACD.DB._getVertices(id, segments),
                        ACD.DB._isPolylineClosed(id), _getStylename(null, "fill:none"));
                    //ACD.WR("I03");
                } else if(ACD.DB._isMLine(id))
                {
                    if(!ACD.DB._getIdName(id).ct_("ROAD"))
                    {
                        pPos[] _cross = cReadData._getMLineVertices(id);

                        res.Add(new pPos[] { _cross[0], _cross[1] }.ExtentLine(0.5));
                        res.Add(new pPos[] { _cross[2], _cross[3] }.ExtentLine(0.5));

                        res.Closed = res.Closed.Add(false);
                        res.Closed = res.Closed.Add(false);
                    }
                } else if(ACD.DB._isWall(id))
                {
                    res.Add(ACD.DB._getVertices(id, segments).ToArray());
                    //ACD.WR("I02.1");
                    res.Closed = res.Closed.Add(false);
                    //ACD.WR("I02.2");
                    region2d.AppendPolylineHtml(ACD.DB._getVertices(id, segments),
                            false, _getStylename(null, "fill:none"));
                }
                else if (ACD.DB._isBlock(id))
                {
                    //ACD.WR("I04");
                    ACD.DB.BlockEntitiesAction(id, _ids => {
                        PosCollection _pls = _idsToPts(_ids, segments);
                        res.AddRange(_pls);

                        for (int _i = 0; _i < _pls.Count; _i++)
                            res.Closed = res.Closed.Add(_pls.Closed[_i]);
                    });
                    //ACD.WR("I05");
                }
                else if(ACD.DB._isCircle(id))
                    _addCircle(id);
                //else if (ACD.DB._isText(id))
                    //region2d.AppendTextHtml(ACD.DB._getContent(id), ACD.DB._getPoint(id));

            //ACD.WR("I06");

            return res;
        }

        static ObjectIdCollection _getAddObjects(ObjectId id)
        {
            pPos[] bb = ACD.DB._getBound(id);

            ACD.DB.GetEntities(null, EN_SELECT.AC_DXF, "INSERT");

            return IR.SelectedIds.ToList()
                .Where(blkId => ACD.DB._getIdName(blkId).st_("add") && ACD.DB._getBound(blkId).Any(p => p.InsideRect(bb[0], bb[1])))
                .ToCollection();
        }

        static void _generate_title_from_linears(PosCollection regions)
        {
            //ACD.WR("TITLES> {0},{1}", regions.Count, inblock_title_linear.Count);
            Dictionary<string, int> dicts = new Dictionary<string, int>();

            foreach (pPos[] _ls in inblock_title_linear)
            {
                List<pPos> res = new List<pPos>();

                foreach (pPos[] _reg in regions)
                    for (int i = 0; i < _ls.Length - 1; i++)
                    {
                        pPos _p1 = _ls[i], _p2 = _ls[i + 1], _p = null;

                        if (_p1.Inside(_reg))
                            _p = _p1.Clone();
                        else if (_p2.Inside(_reg))
                            _p = _p2.Clone();
                        else
                        {
                            pPos[] intpts = _reg.Add(_reg[0]).Intersect(_p1, _p2, false);

                            if (intpts.Length > 0 && intpts.CenterPoint().IsBetween(_p1, _p2))
                                _p = intpts.CenterPoint();
                        }

                        if (_p != null)
                        {
                            _p.Content = _p1.Content;
                            res.Add(_p);

                            break;
                        }
                    }
                
                if (res.Count > 0)
                {
                    res = res.OrderBy(p => p.DistanceTo(_ls[0])).ToList();

                    for (int i = 0; i < res.Count; i++)
                    {
                        if (!dicts.ContainsKey(_ls[0].Content))
                            dicts.Add(_ls[0].Content, 1);

                        int index = dicts[_ls[0].Content];

                        res[i].Content = _ls[0].Content + index;
                        CssData.inblock_titles.Add(res[i]);
                        CssData.TitleList.Add(res[i]);

                        dicts[_ls[0].Content]++;
                    }
                }

            }
        }

        static string _drawItem(ObjectId id)
        {
            //string[] xnote = ACD.DB.GetXNotes(id);
            //ACD.WR("R0");
            List<string> contents = new List<string>();

            ObjectIdCollection srcIds = new ObjectIdCollection() { id };
            srcIds.AddRange(_getAddObjects(id));

            PosCollection pls = _idsToPts(srcIds);
            //List<bool> ls = pls.Closed.ToList();
            pls.AddRange(wallPls);
            int total = pls.Closed.Length;

            for (int i = total; i < pls.Count; i++)
                pls.Closed = pls.Closed.Add(false);


            // Vẽ region
            PosCollection regions = gDraw2DRegionCLS.ComputeRegions(pls);

            //ACD.WR("R1");

            //Lấy title từ regionss
            _generate_title_from_linears(regions);
            //ACD.WR("R2");


            //fence2d.DrawFence(regions, CssData.fence_spacing , 
                //CssData.fence_size , CssData.fence_min);

            double[] region_area_orders = regions.Select(ls => ls.Area().roundNumber(CssData.round))
                .Where(v => v > CssData.min).Distinct().OrderBy(n => n).ToArray();
            //ACD.WR("DR 1");
            PosCollection res = new PosCollection();

            foreach (pPos[] ls in regions)
            {
                double area = ls.Area().roundNumber(CssData.round);

                ls[0].Content = "Region.Area"
                    + DE.NumericArray(1, region_area_orders.Length)
                    .Where(n => area == region_area_orders[n - 1]).FirstOrDefault();

                res.Add(ls);
                res.Closed = res.Closed.Add(true);
            }

            //ACD.WR("DR 2");
            
            if (res.Count > 0)
            {
                //ACD.WR("DR 2.1");
                //ACD.WR("RES: [{0}]", res.Count);
                char[] letters = CssData.AllNameLetters;

                pPos blockpt = ACD.DB._getPoint(id);
                //ACD.WR("DR 2.2");
                if (blockpt != null)
                    contents.Add(CssData.GetHtmlCodeFromBlockPt(blockpt));
                //ACD.WR("DR 2.3");
                //ACD.WR("DR 3");
                contents.AddRange(DE.NumericArray(0, res.Count - 1)
                    .Select(n => {
                        string rs = null;
                        //ACD.WR("DR 2.4");

                        if (CssData.inblock_titles.Any(p => p.Inside(res[n])))
                        { 
                            pPos pt_title = CssData.inblock_titles.FirstOrDefault(p => p.Inside(res[n]));
                            //ACD.WR("DR 4.-1");

                            if (res[n].Area() > 1)// && res[n].Area() < 5000)
                            {
                                draw2d.DrawPolygonItem(res[n], pt_title, 0);
                                csv.AppendCSV(res[n], pt_title, 0);
                                region2d.DrawColor(res[n], pt_title.Content,
                                    _getStylename(pt_title.Content),
                                    Array.IndexOf(letters, pt_title.Content[0]));
                                
                            }
                        }

                        //ACD.WR("DR 4.0");
                        for (int i = 0; i < res[n].Length; i++)
                            res[n][i].Content = "";
                        //ACD.WR("DR 4.1");
                        return rs;
                    }));

                //ACD.WR("DR 5");

                //if (xnote != null && xnote.Length > 0)
                //    contents.AddRange(ACD.DB.GetXNotes(id));

                contents.Add("</div>");

                //for (int i = 0; i < res.Count; i++)
                    //draw2d.DrawGPolyline(res[i], res.Closed[i]);
            }
            //ACD.WR("DR 6");
            return contents.ToTextStr("\r\n");
        }

        static gDraw2DPolygonCLS draw2d;
        static gDraw2DRegionCLS region2d;
        
        static int H = 2000, W = 2000;
        static CSVDataCLS csv;
        static cReadData CssData;
        static PosCollection inblock_title_linear;
        
        static void _gn_ids_title_data(ObjectId id)
        {
            if (ACD.DB._isText(id))
            {
                CssData.inblock_titles.Add(ACD.DB._getPoint(id));
            } else if (ACD.DB._isBlock(id))
            {
                ACD.DB.BlockEntitiesAction(id, (___subIds) => {
                    foreach(ObjectId ___id in  ___subIds)
                        _gn_ids_title_data(___id);
                });
            } else
            {
                string _type = ACD.DB.GetLinetypeText(id);

                if (!_type.empty())
                {
                    pPos[] ls = ACD.DB._getVertices(id).ToArray();
                    ls[0].Content = _type;
                    inblock_title_linear.Add(ls);
                }
            }
        }

        static void _get_linear_titles_from_ids_data(ObjectIdCollection selIds)
        {
            inblock_title_linear = new PosCollection();
            
            foreach(ObjectId id in selIds)
                _gn_ids_title_data(id);
        }

        static PosCollection wallPls;

        public static void StartMethod()
        {
            using (ACD.Lock())
            {
                ACD.WR("<<Note>>Red line is street");
                ACD.WR("!!! For ceiling object, put circle for low ceil plane !!!");
                ACD.WR("!!! Char $ = height, # = cote, +- = level !!!");

                ObjectIdCollection selIds = ACD.GetSelection();

                if (selIds.Count > 0)
                {
                    CssData = new cReadData(selIds);
                    pPos[] bb = ACD.DB._getBound(selIds);

                    CssData.html_basepoint = new pPos(bb[0].X, bb[1].Y);

                    //Tìm basepoint trong nhóm blockIds
                    ObjectIdCollection ___blockIds = selIds.ToList().Where(_id => ACD.DB._isBlock(_id)).ToCollection();

                    if(___blockIds.Count > 0)
                        CssData.html_basepoint = ACD.DB._getPoint(___blockIds.ToList().OrderBy(_id =>
                            {
                                var __sz = ACD.DB._getBound(_id).Size();
                                return - __sz.X * __sz.Y;
                            }).First());

                    // Tìm wallIds để xác định tim đường, đồng thời xác định con đường street

                    wallPls = selIds.ToList().Where(_id => ACD.DB._isWall(_id))
                        .Select(_id => ACD.DB._getVertices(_id)).ToCollectionSameClosed(false);

                    //if (!firstId.IsNull)
                    //    CssData.html_basepoint = ACD.DB._getPoint(firstId);

                    // Tìm tên theo lines có đánh dấu tên
                    inblock_title_linear = new PosCollection();
            
                    foreach(ObjectId id in selIds)
                        _gn_ids_title_data(id);

                    csv = new CSVDataCLS(CssData);

                    W = (int)(1.5 * bb.Size().X * CssData.drawing_scale).roundNumber(100);
                    H = (int)(1.5 * bb.Size().Y * CssData.drawing_scale).roundNumber(100);

                    //Ghi file 3D
                    gWallExtCLS gWall = new gWallExtCLS(selIds, CssData);
                    gWall.ToHtml(@"D:\html\wallinfo.html");

                    draw2d = new gDraw2DPolygonCLS(CssData);
                    region2d = new gDraw2DRegionCLS(CssData);

                    foreach(ObjectId id in selIds)
                         _drawItem(id);
                                    
                    //foreach(pPos[] ls in gWall.pavementList)
                        //region2d.DrawColor(ls.Select(__p => __p / gWall.__sc).ToArray(), "MT_PAVE_#200");
                        //_addCSSData_inblocktitle(ls.CenterPoint() / __sc, "MT_PAVE_#200");
                    //ACD.WR("Total cross {0}", gWall.crossRoadList.Count);
                    foreach(pPos[] ls in gWall.crossRoadList)
                    {
                        //ACD.DB.CreateText(cReadData._getCrossRoadMtlAxis(ls), ls.CenterPoint());
                        draw2d.DrawPolygonItem(ls, pPos.FromString("0,0,0[WALK]"));
                        region2d.DrawColor(ls, cReadData._getCrossRoadMtlAxis(ls));
                    }

                    //Ghi file Csv ?_csv.csv, lấy dữ liệu đầu vào table_data cho hàm WriteHtml
                    string table_data = csv.SaveCSV(@"D:\html\" 
                        + Path.GetFileNameWithoutExtension(ACD.CurrentDWGFileName) + "_cls.csv");

                    //Ghi file Html plan_html.html
                    WriteHtmlCLS.WriteHtml(CssData, W, H, table_data);

                    
                        
                    ACD.Focus();
                }

                ACD.Focus();
            }
        }
    }
}

