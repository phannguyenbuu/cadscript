﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;

namespace AcadScript
{
    public class CSVDataCLS
    {
        List<string> contents;
        cReadData CssData;
        double total_area = 0;
        int total = 0;
        
        public static double _getRegionAngle(pPos[] pts)
        {
            pPos[] line = pts.MaxSegment().OrderBy(p => p.X).ThenBy(p => p.Y).ToArray();
            return (line[0] - line[1]).Angle();// / 180 * Math.PI;
        }

        public static pPos _getRegionSize(pPos[] pts)
        {
            PosCollection segments = pts.GetSegment().OrderBy(seg
                => -seg.Length(false)).ToCollectionSameClosed(false);

            List<pPos> ls = segments[0].ToList();
            ls.AddRange(segments[1].Reverse());

            pPos ct = ls.CenterPoint();

            pPos[] bb = pts.Rotate(-90 + _getRegionAngle(pts), ct).Boundary();

            ct.Content = _rounN(bb.Size().X, 5, 8, 16, 20) + " x " + _rounN(bb.Size().Y, 5, 8, 16, 20);

            //pPos p1 = new pPos((bbs[0].X + bbs[1].X) / 2, bbs[1].Y).Rotate(-angle + 90, ct);
            //pPos p2 = new pPos((bbs[0].X + bbs[1].X) / 2, bbs[0].Y).Rotate(-angle + 90, ct);
            //pPos[] itps = pts.Intersect(p2.AlongRatio(p1, 1.1), p1.AlongRatio(p2, 0.9)).OrderBy(p => -p.Y).ToArray();

            return ct;
        }

        public CSVDataCLS(cReadData _css)
        {
            //filename = _filename;
            contents = new List<string>();

            total_area = 0;
            total = 0;

            CssData = _css;
        }

        public string SaveCSV(string filename)
        {
            //ACD.WR("Content: {0}", contents.ToTextStr("\r\n"));
            string res = "<div class=\"split right\">\r\n" + "<div class=\"centered\">\r\n" + "<table>\r\n";

            contents = contents.OrderBy(s => s.filter(",")[0][0])
                .ThenBy(s => s.filter(",")[0].Substring(1).ToNumber())
                .ThenBy(s => s.filter(",")[0]).ToList();

            contents = DE.NumericArray(0, contents.Count - 1).Select(n => (n + 1) + "," + contents[n]).ToList();

            contents.Add(">,Total," + total_area.roundNumber(0.01) + "(m2)," + total + "(items)");

            res += "\t<tr>\r\n";
            int rows = 20;

            for (int j = 0; j <= Math.Ceiling((double)(contents.Count / rows)); j++)
            {
                res += "\t\t<th>No</th>\r\n";
                res += "\t\t<th>Name</th>\r\n";
                res += "\t\t<th>Area</th>\r\n";
                res += "\t\t<th>Dimension</th>\r\n";
                res += "\t\t<th>|</th>\r\n";
            }

            res += "\t</tr>\r\n";
            
            for(int i = 0; i < rows; i ++)
            {
                string st = "";
                res += "\t<tr>\r\n";

                for (int j = 0; j <= Math.Ceiling((double)(contents.Count / rows)); j++)
                {
                    int index = j * rows + i;
                
                    if (index < contents.Count)
                        st += contents[index] + ",|,";
                }

                int cnt = 0;
                string[] ar = st.filter(",");

                foreach (string _s in st.filter(","))
                {
                    if(st.ct_("Total"))
                        res += "\t\t<th style = \"background: yellow;\">";
                    else if(cnt == 2)
                        res += "\t\t<th style = \"background: lightgray;\">";
                    else
                        res += "\t\t<th>";

                    res += _s + "</th>\r\n"; 

                    cnt++;
                }
                
                res += "\t</tr>\r\n";
            }

            contents.Insert(0, "No,Name,Area,Dimension");
            contents.Add("Count," + total + " items");
            contents.Add("Area," + total_area);

            File.WriteAllLines(filename, contents.ToArray());

            res += "</table>";
            res += "\r\n\t" + "</div>\r\n</div>\r\n";

            return res;
        }

        public static double _rounN(double v, params double[] base_rounds)
        {
            double res = v;

            foreach (double base_round in base_rounds)
                if (v < base_round && Math.Abs(v - base_round) < 0.8)
                {
                    res = base_round;
                    break;
                }

            return res.roundNumber(0.01);
        }

        public void AppendCSV(pPos[] pts, pPos pt_title, int counter = 0)
        {
            //float angle = CssData.drawing_angle == -999 ? _getRegionAngle(pts) : (float)CssData.drawing_angle;
            //int axis = drawing_axis == -1 ? (((int)Math.Floor((angle + 360) / 90)) % 2 == 1 ? 0 : 1) : drawing_axis;
            string s_caption = CssData.CaptionList._props(pt_title.Content);
            //ACD.WR("Caption Key {0} Value {1}", key, s_caption);

            if (s_caption.empty())
                s_caption = pt_title.Content;

            if (!contents.Any(s => s.StartsWith(s_caption + ",")))
            {
                string s_area = CssData.AreaList._props(pt_title.Content);
                double area = (pts.Area()).roundNumber(0.01);

                if (s_area.empty())
                    s_area = "" + _rounN(area, 80, 100, 200, 500, 1000);

                //_appendCSV(pts, s_caption, s_area);
                
                pPos pt = _getRegionSize(pts);

                //Kích thước lô đất lưu trong pt.content

            
                contents.Add(String.Format("{0},{1},{2}", s_caption,
                    //fullname + "-" + xnotes[i]._firstPropName(),
                    s_area.empty() ? _rounN(pts.Area(), 80, 100, 200, 500, 1000).ToString() : s_area, pt.Content));

                total_area += pts.Area();
                total++;
            }
        }
    }
}
