﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;

using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.Runtime;

namespace AcadScript
{

    public class gWallExtCLS
    {
        //Dictionary<string, string> dicts;
        //string html_content;

        
        pPos __basept = new pPos(0, 0);
        pPos __sz = new pPos(0, 0);
        pPos[] __blockPts;

        cReadData CSSData;

        public PosCollection mtlList, crossRoadList, centerRoadList, treeList, pavementList, roadList; // Lối băng qua đường, tim đường
        string[] plsMtlNames;
        ObjectIdCollection srcIds;

        //PosCollection pls;
        bool _isPlan = false;

        public gWallExtCLS(ObjectIdCollection selIds,  cReadData _css)
        {
            CSSData = _css;
            __basept = CSSData.html_basepoint;
            srcIds = new ObjectIdCollection();

            centerRoadList = new PosCollection();
            crossRoadList = new PosCollection();
            treeList = new PosCollection();

            pavementList = new PosCollection();
            roadList = new PosCollection();

            if (selIds.ToList().Any(__id => ACD.DB._getIdName(__id).st_("plan")))
            {
                _isPlan = true;
                cReadData.__sc = 1000;
            }

            //ACD.WR(">>> selIds {0} scale {1}", selIds.Count, cReadData.__sc);

            _getMtlList(selIds);

            __sz = ACD.DB._getBound(srcIds).Size();
            
            __blockPts = ACD.DB.FilterIds(srcIds, "INSERT").ToList().Select(id => ACD.DB._getPoint(id)).ToArray();

            if (__blockPts.Any(p => p.Content.ct_("grid")))
                __basept = __blockPts.First(p => p.Content.ct_("grid"));

            __blockPts = __blockPts.Where(p => !p.Content.ct_("grid") && !p.Content.st_("*U")).ToArray();

            __basept *= cReadData.__sc;

            //ACD.WR(">>> {0}, mtlList:{1},{2}", cReadData.__sc, mtlList.Count, srcIds.Count);
        }

        void __getSubMtlList(ObjectId _id)
        {
            string st = ACD.DB.GetLinetypeText(_id);

            if (ACD.DB._isPolyline(_id) || ACD.DB._isLine(_id))
            {
                if (st.st_("MTL") || st.st_("ML") || st.st_("MT"))
                {
                    pPos[] ls = ACD.DB._getVertices(_id, 0, false);

                    foreach (pPos _p in ls)
                        _p.Content = st;

                    mtlList.Add(ls);
                }
            }
            else if (ACD.DB._isMLine(_id))
            {
                string _type = ACD.DB._getIdName(_id);
                pPos[] ls = ACD.DB._getVertices(_id, 0, false);

                if (_type.ct_("ROAD"))
                    centerRoadList.Add(ls);
                else if (_type.ct_("WALK"))
                {
                    pPos[] _lls = cReadData._getMLineVertices(_id);

                    if(_lls.Area() > 3)
                        crossRoadList.Add(_lls.ToArray());
                }
            }
            else if (ACD.DB._isBlock(_id))
            {
                ACD.DB.BlockEntitiesAction(_id, _subIds =>
                {
                    foreach (ObjectId _sid in _subIds)
                        __getSubMtlList(_sid);
                });
            }
        }

        void _getMtlList(ObjectIdCollection selIds)
        {
            mtlList = new PosCollection();

            foreach (ObjectId _id in selIds)
            {
                if (ACD.DB._isBlock(_id))
                    srcIds.Add(_id);
                
                __getSubMtlList(_id);
            }

            List<pPos> res = new List<pPos>();

            foreach (pPos[] _road in centerRoadList)
            {
                //foreach (pPos _p in _road)
                //{
                //    _p.Content = "MT_ROAD";
                //    res.Add(_p.Clone());
                //}

                foreach (pPos[] _cross in crossRoadList)
                {
                    pPos[] _xs = _cross.Intersect(_road[0], _road[1], true);

                    if (_xs.Length > 1)
                    {
                        pPos p1 = _xs[0].Along(-1, _xs[1]);
                        pPos p2 = _xs[1].Along(-1, _xs[0]);
                        p1.Content = p2.Content = "MT_ROAD";
                        
                        res.Add(p1);
                        res.Add(p2);
                    }
                }
            }

            mtlList.Add(res.ToArray());

            //foreach(pPos[] ls in mtlList)
            //{
            //    foreach(pPos p in ls)
            //        if (p.Content == "MT_ROAD")
            //            ACD.DB.DrawCircle(p, 1);
            //}

            //ACD.WR(">>> IDS {0}", srcIds.Count);
        }

        

        public void ToHtml(string filename)
        {
            string content = "<head>\r\n"
                + "<link rel = \"stylesheet\" href = \"styles/cadstyle.css\">\r\n"
                + "</head>\r\n"
                + "<svg width=\"" + __sz.X * cReadData.__sc.roundNumber(0.01) + "\""
                + " height =\"" + __sz.Y * cReadData.__sc.roundNumber(0.01) + "\">\r\n";

            content += "\t" + __comment("Scale=" + cReadData.__sc);
            content += "\t" + __comment("WallHeight=" + 3600 / cReadData.__sc);
            content += "\t" + __comment("WallTop=");
            content += "\t" + __comment("WallBottom=");
            content += "\t" + __comment("WallBorder=");
            content += "\t" + __comment("CeilBorder=" + 150 / cReadData.__sc);
            content += "\t" + __comment("DoorTop=" + 2800 / cReadData.__sc);
            content += "\t" + __comment("WindowTop=" + 2800 / cReadData.__sc);
            content += "\t" + __comment("WindowBottom=" + 2800 / cReadData.__sc);
            content += "\t" + __comment("DisplayFilter=");

            //ACD.WR("To Html {0} - {1} - {2}", srcIds.ToList().Select(id => id.ObjectClass.DxfName).ToTextStr(","), 
                //ACD.DB.FilterIds(srcIds, "AEC_WALL").Count, ACD.DB.FilterIds(srcIds, "INSERT").Count);

            ObjectIdCollection wIds = ACD.DB.FilterIds(srcIds, "AEC_WALL", "MLINE");

            if (wIds.Count > 0)
            {
                content += gWallToHtml(wIds);
            }

            content += gBlockToHtml(ACD.DB.FilterIds(srcIds, "INSERT"));

            foreach (pPos[] ls in centerRoadList)
                for (int i = 0; i < ls.Length - 1; i++)
                {
                    content += "\t" + __comment("WallLine");

                    List<pPos> _lls = ls[i].Parallel(ls[i + 1], 0.1).ToList();
                    _lls.AddRange(ls[i + 1].Parallel(ls[i], 0.1));

                    content += "\t" + __transStrList(_lls.Select(_p => _p * cReadData.__sc), " style = \"fill:red;fill-opacity:0.5\"");
                }


            foreach(pPos[] ls in mtlList)
                foreach(pPos _p in ls)
                    _addCSSData_inblocktitle(_p, ls[0].Content);
            
            foreach(pPos[] ls in pavementList)
                _addCSSData_inblocktitle(ls.CenterPoint() / cReadData.__sc, "MT_PAVE_#200");
                
            // foreach(pPos[] ls in crossRoadList)
            //     _addCSSData_inblocktitle(ls.CenterPoint() / cReadData.__sc, _getCrossRoadMtlAxis(ls));

            content += "</svg>\r\n";

            Directory.CreateDirectory(Path.GetDirectoryName(filename));
            File.WriteAllText(filename, content);
        }

        void _addCSSData_inblocktitle(pPos _p, string _content)
        {
            _p.Content = _content;
            CSSData.inblock_titles.Add(_p);
        }

        double[] getElipInfo(Database db, ObjectId objId)
        {
            double[] res = null;
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                if (objId.ObjectClass.DxfName == "ELLIPSE")
                {
                    Ellipse elp = (Ellipse)tr.GetObject(objId, OpenMode.ForRead);
                    double rot = elp.StartPoint.ToPos().AngleVector(elp.Center.ToPos(), elp.StartPoint.ToPos() + new pPos(1, 0));
                    res = new double[] { elp.MajorRadius, elp.MinorRadius, rot };
                }

                tr.Commit();
            }
            return res;
        }

         bool isVerts_(pPos[] pts, string xnote)
        {
            pPos[] bb = pts.Boundary();
            pPos sz = bb.Size();
            PosCollection segs = pts.GetSegment().OrderBy(sg => sg.Length(false)).ToCollectionSameClosed(false);

            string[] ar = xnote.filter(";");

            for (int i = 0; i < ar.Length; i++)
            {
                string res = ar[i];
                bool equal = !res.ct_(">") && !res.ct_("<");

                if (res.st_("n"))
                {
                    res = pts.Length + (equal ? "=" : "") + res.Substring(1);
                }

                else if (res.st_("seg_") && res.ct_("<"))
                    res = segs.First().Length(false) + res.Substring(4);
                else if (res.st_("seg_") && res.ct_(">"))
                    res = segs.Last().Length(false) + res.Substring(4);
                else if (res.st_("seg") && res.ct_("<"))
                    res = segs.Last().Length(false) + res.Substring(3);
                else if (res.st_("seg") && res.ct_(">"))
                    res = segs.First().Length(false) + res.Substring(3);

                else if (res.st_("s") && res.ct_(">"))
                    res = Math.Min(sz.X, sz.Y) + res.Substring(1);

                else if (res.st_("r") && res.ct_(">"))
                    res = Math.Max(sz.X, sz.Y) + res.Substring(1);
                else if (res.st_("s") && res.ct_("<"))
                    res = Math.Max(sz.X, sz.Y) + res.Substring(1);
                else if (res.st_("r") && res.ct_("<"))
                    res = Math.Min(sz.X, sz.Y) + res.Substring(1);
                else if (res.st_("w"))
                    res = sz.X + (equal ? "=" : "") + res.Substring(1);
                else if (res.st_("h"))
                    res = sz.X + (equal ? "=" : "") + res.Substring(1);
            }

            return true;
        }

         string _getContentFromColorIndex(string content, ObjectId id)
        {
            int color_index = ACD.DB._getColorIndex(id);

            string[] ar = content.filter("()");
            string res = content;

            if (ar.Length > color_index)
            {
                res = ar[color_index];
                ar = res.filter(" ");

                //ACD.WR("ARR {0}", ar.ToTextStr(","));
                res = "";

                for (int ii = 0; ii < ar.Length; ii++)
                    if (!ar[ii].st_("#"))
                    {
                        string s = ar[ii];

                        List<double> ls = new List<double>();
                        string[] _ar = (s.st_("h") ? s.Substring(1) : s).filter("&");

                        for (int i = 0; i < _ar.Length; i++)
                        {
                            string _s = _ar[i];

                            if (_s.ct_("x"))
                                ls.AddRange(DE.NumericArray(0,
                                    (int)(_s.filter("x").Last().ToNumber()) - 1)
                                    .Select(_i => _s.filter("x").First().ToNumber() * 100));
                            else
                                ls.Add(_s.ToNumber() * 100);

                            _ar[i] = ls.ToTextDouble("&");
                        }

                        ar[ii] = (ar[ii].st_("h") ? "h" : "") + _ar.ToTextStr("&");
                    }

                res = ar.ToTextStr(" ");
            }

            return res;
        }

         string __transStrList(IEnumerable<pPos> pts, string _extent_info = "")
        {
            return "<polyline points =\""
                + pts.Select(p => new pPos(p.X - __basept.X, p.Y - __basept.Y)).ToText(false, ' ') + "\"" + _extent_info + "/>\r\n";
        }

        string _getNearestBlock(pPos p1, pPos p2)
        {
            string res = "";

            if (__blockPts.Length > 0)
            {
                res = "\t" + __comment("NearestBlock=" + __blockPts.OrderBy(p => p.DistanceTo(p1, p2)).First().Content);
            }

            return res;
        }

         PosCollection _getWallRectChains(pPos p1, pPos p2, double w, PosCollection opnPls)
        {
            PosCollection pls = new PosCollection();
            PosCollection res = new PosCollection();

            pPos[] line1 = p1.Parallel(p2, w);

            if (opnPls.Count > 0)
            {
                pls.Add(new pPos[] { p1, opnPls[0][0] });

                for (int i = 0; i < opnPls.Count; i++)
                {
                    pls.Add(opnPls[i]);
                    pls.Add(new pPos[] { opnPls[i][1], i == opnPls.Count - 1 ? p2 : opnPls[i + 1][0] });
                }

                //pls.Add(new pPos[] { opnPls.Last()[1], p2 });

                res = pls.Select(_l => new pPos[] {_l[0].Project2D(p1, p2),
                    _l[1].Project2D(p1, p2), _l[1].Project2D(line1[0], line1[1]),
                    _l[0].Project2D(line1[0], line1[1])}).ToCollectionSameClosed(true);

                res.Closed = res.Select(_l => true).ToArray();
            }
            else
            {
                res = new PosCollection() { new pPos[] { p1, p2, line1[1], line1[0] } };
                res.Closed = new bool[] { true };
            }

            return res;
        }

         PosCollection _getWallIShape(ObjectIdCollection subIds, pPos p1, pPos p2, double w, PosCollection opnPls)
        {
            PosCollection rects = new PosCollection();

            ObjectIdCollection hIds = subIds.FilterIds("HATCH");
            //ACD.WR("S{0} H {1}", subIds.Count, hIds.Count);

            if (hIds.Count > 0)
            {
                PosCollection h_pls = new PosCollection();

                foreach (ObjectId _hid in hIds)
                    h_pls.AddRange(ACD.DB._getHatch(_hid));

                h_pls.Closed = h_pls.Select(_l => true).ToArray();

                rects = _getWallRectChains(p1, p2, w, opnPls);

                //ACD.DB.DrawPolyline(rects);
                //ACD.DB.DrawPolyline(h_pls);

                if (!h_pls.AllPoints.Any(_p => rects.Any(_l => _p.Inside(_l))))
                {
                    rects = _getWallRectChains(p1, p2, -w, opnPls);

                    if (!h_pls.AllPoints.Any(_p => rects.Any(_l => _p.Inside(_l))))
                        rects = new PosCollection();
                }

            }

            ACD.DB.EraseObjects(subIds);

            return rects;
        }

         pPos _getWFromStyle(string style)
        {
            double w = 0;
            double h = 3000;

            if (style.ct_("100"))
                w = 100;
            else if (style.ct_("150"))
                w = 150;
            else if (style.ct_("200"))
                w = 200;
            else if (style.ct_("250"))
                w = 250;
            else if (style.ct_("300"))
                w = 300;
            else if (style.ct_("Fence"))
            {
                w = 0.05;
                h = 1;
            }

            return new pPos(w, h);
        }

        string _getWallOpeningInfo(ObjectId entId)
        {
            Database db = ACD.DB;
            string content = "";

            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                if (entId.ObjectClass.DxfName == "AEC_WALL")
                {
                    Autodesk.Aec.Arch.DatabaseServices.Wall wall
                        = (Autodesk.Aec.Arch.DatabaseServices.Wall)tr.GetObject(entId, OpenMode.ForRead);

                    if (wall != null)
                    {
                        string style = ACD.DB._getIdName(entId);

                        ObjectIdCollection srcIds = wall.GetOpeningsFor();
                        PosCollection opnPls = new PosCollection();

                        List<pPos> cts = new List<pPos>();

                        foreach (ObjectId id in srcIds)
                        {
                            pPos[] _l = db._getVertices(id).OrderBy(_p => _p.DistanceTo(wall.StartPoint.ToPos())).ToArray();
                            
                            opnPls.Add(_l);
                            cts.Add(_l.CenterPoint());
                            cts.Last().Content = db._getIdName(id);
                        }

                        opnPls = opnPls.OrderBy(_l => _l.CenterPoint().DistanceTo(wall.StartPoint.ToPos())).ToCollectionSameClosed(false);

                        pPos sz = _getWFromStyle(style);

                        if (sz.X == 0)
                            sz.X = wall.Width;

                        PosCollection rects = _getWallIShape(ACD.DB.ExplodeAEC(new ObjectIdCollection { entId }, false),
                            wall.StartPoint.ToPos(), wall.EndPoint.ToPos(), sz.X, opnPls); // _getWFromStyle(style)

                        foreach (pPos[] r in rects)
                        {
                            pPos[] _cts = cts.Where(_p => _p.Inside(r)).ToArray();

                            if (_cts.Length > 0)
                            {
                                string _style = _cts[0].Content;

                                if (!_style.ct_("Opening"))
                                {
                                    content += "\t" + __comment("Opening=" + _style);
                                    content += "\t" + __transStrList(r.Select(_p => _p * cReadData.__sc),
                                        " style = \"fill:" + (_style.st_("d") ? "green" : "blue") + ";fill-opacity:0.5\"");
                                }
                            }
                            else
                                content += "\t" + __transStrList(r.Select(_p => _p * cReadData.__sc), 
                                    " style = \"fill:red;fill-opacity:0.5\"");
                        }
                    }
                }

                tr.Commit();
            }

            return content;
        }

         string __comment(string s)
        {
            return "<!-- " + s + " -->\r\n";
        }

        string gWallToHtml(ObjectIdCollection __ids)
        {
            string content = "";
            List<pPos> wallPts = new List<pPos>();

            foreach (ObjectId wallId in __ids)
            {
                string style = ACD.DB._getIdName(wallId);
                pPos[] points = ACD.DB._getVertices(wallId).ToArray();

                if (style.ct_("WallLine") || style.ct_("ROAD"))
                {
                    pPos pt = points.CenterPoint();
                    pt.Content = "MT_ROAD";
                    wallPts.Add(pt);
                }

                content += "\t" + __comment(style);
                //content += "\t" + __transStrList(ACD.DB._getVertices(wallId));
                content += _getWallOpeningInfo(wallId);
                content += _getNearestBlock(points[0], points[1]);
                content += "\r\n";
            }

            //ACD.WR("Wall {0} srcIds {1}", wallPts.ToText(true, ','), __ids.Count);

            //foreach (pPos p in wallPts)
                //ACD.DB.DrawCircle(p, 50, "LAYER=A-FIN");

            if (wallPts.Count > 0)
                mtlList.Add(wallPts.ToArray());

            return content;
        }

        pPos[] _gnTrees(pPos[] pts, double spacing = 20)
        {
            PosCollection _fsegs = pts.GetSegment(true);
            PosCollection segs = new PosCollection();
            PosCollection _pls = new PosCollection();
            spacing *= cReadData.__sc;

            for (int i = 0; i < _fsegs.Count; i++)
            {
                segs.Add(_fsegs[i][0].Parallel(_fsegs[i][1], 0.5 * cReadData.__sc));
                segs.Add(_fsegs[i][0].Parallel(_fsegs[i][1], -0.5 * cReadData.__sc));
            }

            foreach (pPos[] _seg in segs)
            {
                double d = _seg.Length(false);
                
                if (d >= spacing)
                {
                    List<pPos> ls = new List<pPos>();

                    for (int i = 0; i <= Math.Floor(d / spacing); i++)
                        ls.Add(_seg[0].Along(spacing * i, _seg[1]));

                    if (ls.Count > 0)
                        _pls.Add(ls.ToArray());
                }
            }

            return _pls.AllPoints;
        }

        void _regionMtlFilter(PosCollection pls)
        {
            string[] pointnames = pls.AllPoints.Select(_p 
                => _p.X.roundNumber() + "," + _p.Y.roundNumber()).Distinct().ToArray();

            List<int[]> namelist = new List<int[]>();
            List<int> checkPointNames = new List<int>();

            for(int i = 0; i < pls.Count; i ++)
            {
                var val = pls[i].Select(_p => Array.IndexOf(pointnames, 
                    _p.X.roundNumber() + "," + _p.Y.roundNumber())).ToArray();

                if (!plsMtlNames[i].et_()) 
                    checkPointNames.AddRange(val);
                
                namelist.Add(val);
            }

            checkPointNames = checkPointNames.Distinct().ToList();
            //ACD.WR("Road {0}", checkPointNames.ToTextInt(","));

            for (int i = 0; i < pls.Count; i++)
                if (plsMtlNames[i].et_() && namelist[i].Any(n => checkPointNames.Contains(n)))
                     plsMtlNames[i] = "MT_PAVE_#200";

        }

        string _getExtendInfoFromContent(string content)
        {
            string ext_info = null;
            double cote = 0, h = 0;

            string[] ar = content.filter("_");

            h = ar.FirstOrDefault(_s => _s.st_("$")).ToNumber();
            double nlevel = ar.FirstOrDefault(_s => _s.st_("+") || _s.st_("-")).ToNumber();
            cote = ar.FirstOrDefault(_s => _s.st_("#")).ToNumber();
            
            ext_info = " mtl=\"" + content + "\"";

            if (h != 0)
                ext_info += " h=\"" + h + "\"";

            if (cote != 0)
                ext_info += " z=\"" + cote + "\"";

            return ext_info;
        }

        void _addTrees(pPos[] pts, double dist)
        {
            List<pPos> newtrees = new List<pPos>();

            foreach (pPos __p in pts)
            {
                bool found = false;
                foreach (pPos __tp in treeList.AllPoints)
                    if (__p._isVeryClosed(__tp, dist * cReadData.__sc))
                    {
                        found = true;
                        break;
                    }

                if (!found)
                    newtrees.Add(__p);
            }

            if(newtrees.Count > 0)
                treeList.Add(newtrees.ToArray());
        }

        string gBlockToHtml(ObjectIdCollection __ids)
        {
            string content = "";
            //ACD.WR("FLOOR 00-1");

            foreach (ObjectId id in __ids)
            {
                string style = ACD.DB._getIdName(id);
                //ACD.WR("FLOOR 00-2:{0}", style);

                if (style.st_("floor") || style.st_("ceil") || style.st_("plan"))
                {
                    //ACD.WR("FLOOR 00-3:{0}", style);
                    pPos[] bounds = null;

                    ACD.DB.BlockEntitiesAction(id, _ids =>
                    {
                        pPos[] _is_ceil_list = _ids.ToList().Where(_id 
                            => ACD.DB._isCircle(_id)).Select(_id => ACD.DB._getPoint(_id)).ToArray();

                        PosCollection pls = ACD.DB._getAllVertices(_ids.FilterIds("LWPOLYLINE","LINE").ToList()
                            .Where(__id => !ACD.DB._getLayer(__id).ct_("DEFPOINTS")).ToCollection(), 16);

                        for (int i = 0; i < pls.Count; i++)
                            if (pls.Closed[i])
                                pls[i] = pls[i].Add(pls[i].First());

                        foreach (pPos[] _cross in crossRoadList)
                        {
                            pls.Add(new pPos[] { _cross[0], _cross[1] }.ExtentLine(0.1));
                            pls.Add(new pPos[] { _cross[2], _cross[3] }.ExtentLine(0.1));
                        }

                        pls = pls.Select(_ls => _ls.Select(_p => _p * cReadData.__sc).ToArray()).ToCollectionSameClosed(false);

                        if (pls.Count > 0)
                            bounds = pls.OrderBy(_ls => -_ls.Area()).ToCollectionSameClosed(true).First();
                        
                        GraphConsole.Compute(pls);
                        pls = GraphConsole.ResultPts;
                        plsMtlNames = new string[pls.Count];
                        
                        if (_isPlan)
                            _generateCrossRoad(pls);

                        for(int i = 0; i < pls.Count; i ++)
                        {
                            //ACD.WR("F0");
                            pPos[] pts = pls[i];
                            //ACD.WR("F1");
                            //ACD.WR("F:{0}", plsMtlNames[i]);

                            if (plsMtlNames[i].et_() && style.st_("floor") || style.st_("plan"))
                                foreach (pPos[] _mtl in mtlList)
                                    if(_mtl.Length > 0)
                                    {
                                        //ACD.WR("F1.0");
                                        //ACD.WR(_mtl.ToString());

                                        double nz = 0, cote = 0, h = 0;
                                        string[] ar = _mtl[0].Content.filter("_");

                                        //ACD.WR("F1.1");
                                        h = ar.FirstOrDefault(_s => _s.st_("$")).ToNumber();
                                        double nlevel = ar.FirstOrDefault(_s => _s.st_("+") || _s.st_("-")).ToNumber();
                                        cote = ar.FirstOrDefault(_s => _s.st_("#")).ToNumber();
                                        nz = cote;
                                        //ACD.WR("F1.2");
                                        string sstyle = "";

                                        foreach (string s in ar)
                                            if (!s.st_("#"))
                                                sstyle += s + "_";
                                        //ACD.WR("F1.3");
                                        foreach (pPos _mp in _mtl)
                                        {
                                            if ((_mp * cReadData.__sc).Inside(pts))
                                            {
                                                plsMtlNames[i] = sstyle + "_#" + nz;
                                                break;
                                            }

                                            nz += nlevel;
                                        }
                                    }
                        }

                        _regionMtlFilter(pls);
                        //ACD.WR("F4");
                        int n = 0;

                        for(int i = 0; i < pls.Count; i++) //(pPos[] pts in pls)
                        {
                            if (plsMtlNames[i].ct_("PAVE"))
                                pavementList.Add(pls[i]);
                            else if (plsMtlNames[i].ct_("ROAD"))
                                roadList.Add(pls[i]);

                            n ++;

                            content += "\t" + __comment("Floor");
                            content += "\t" + __transStrList(pls[i], _getExtendInfoFromContent(plsMtlNames[i])) + "\r\n";
                        }



                    });

                    if (ACD.DB._getIdName(id).st_("ceil"))
                    {
                        if (bounds != null)
                        {
                            content += "\t" + __comment("CeilBound");
                            content += "\t" + __transStrList(bounds);
                            content += "\r\n";
                        }
                    }
                }
            }

            return content;
        }

        pPos[] boundPtsStraighten(pPos[] pts, double angle)
        {
            angle = CSVDataCLS._getRegionAngle(pts);

            PosCollection segments = pts.GetSegment().OrderBy(seg
                => -seg.Length(false)).ToCollectionSameClosed(false);

            List<pPos> bb = segments[0].ToList();
            bb.AddRange(segments[1].Reverse());

            pPos ct = bb.CenterPoint();// pts.Centroid();

            pPos[] bbs = pts.Rotate(-90 + angle, ct).Boundary();

            pPos p1 = new pPos((bbs[0].X + bbs[1].X) / 2, bbs[1].Y).Rotate(-angle + 90, ct);
            pPos p2 = new pPos((bbs[0].X + bbs[1].X) / 2, bbs[0].Y).Rotate(-angle + 90, ct);

            p1 = p2.AlongRatio(p1, 1.1);
            p2 = p1.AlongRatio(p2, 0.9);

            pPos[] itps = pts.Intersect(p1, p2).OrderBy(p => -p.Y).ToArray();

            return bbs;
        }

        
        void _generateCrossRoad(PosCollection pls)
        {
            for (int i = 0; i < pls.Count; i++)
                if (plsMtlNames[i].et_())
                {
                    pPos[] pts = pls[i];
                    pPos[] ls = crossRoadList.FirstOrDefault(_ls => pts.CenterPoint().Inside(_ls));

                    if (ls != null)
                    {
                        //double angle = CSVDataCLS._getRegionAngle(ls);
                        //string val = Math.Sin(angle / 180 * Math.PI) < 0.5 ? "MT_WALK_1" : "MT_WALK_2";
                        plsMtlNames[i] = cReadData._getCrossRoadMtlAxis(ls);
                    }
                    else if (plsMtlNames[i].et_() && (pts.Length == 4 || pts.Length == 5))
                    {
                        //double angle = CSVDataCLS._getRegionAngle(pts);
                        pPos[] bb = boundPtsStraighten(pts, CSVDataCLS._getRegionAngle(pts));
                        double sz = Math.Min(bb.Size().X, bb.Size().Y);

                        if (sz < 3.5 * cReadData.__sc)
                        {
                            //ACD.WR("Size {0}x{1} - L {2}", bb.Size().X, bb.Size().Y, pts.Length);
                            //string val = Math.Sin(angle / 180 * Math.PI) < 0.5 ? "MT_WALK_1" : "MT_WALK_2";
                            plsMtlNames[i] = cReadData._getCrossRoadMtlAxis(pts);
                        }
                    }
                }
        }
    }
}
