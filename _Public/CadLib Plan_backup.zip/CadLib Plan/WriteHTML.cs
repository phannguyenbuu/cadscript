using System.Drawing;
using System;
using System.Globalization;
using System.Collections.Generic;
using System.Linq;
using System.IO;

using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.Runtime;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.Colors;
using Autodesk.AutoCAD.Internal;


using System.Windows.Forms;
//using SyncObject;
//using Photoshop;

namespace AcadScript
{
    public class WriteHtmlCLS
    {
        static cReadData CssData;
        static List<string> Contents;
        static int W, H;

        static string _repLessTen(string s)
        {
            string snum = "0123456789";
            int index = -1;

            foreach (char c in snum)
            {
                index = s.IndexOf(c);

                if (index != -1)
                    break;
            }

            if(index != -1)
            {
                string val = s.Substring(index);
                
                if(val.ToNumber() < 10)
                    s = s.Replace(val, "0" + val);
                
            }

            return s;
        }


        static string __comment(string s)
        {
            return "<!-- " + s + " -->\r\n";
        }


        static void __save_wall_html()
        {
            pPos __sz = new pPos(100, 100);
            
            int _w = (int)(__sz.X * CssData.drawing_scale.roundNumber(0.01)) * 2;
            int _h = (int)(__sz.Y * CssData.drawing_scale.roundNumber(0.01)) * 2;

            string content = "<head>\r\n"
                            + "<link rel = 'stylesheet' href = 'styles/cadstyle.css'>\r\n"
                            + "</head>\r\n"
                            + "<svg width='" + _w + "'"
                            + " height ='" + _h + "'"
                            + " cReadData ='0 0 " + _w + " " + _h + "'"
                            + ">\r\n";

            content += "\t" + __comment("Scale=" + CssData.drawing_scale);
            content += "\t" + __comment("WallHeight=1.2");
            content += "\t" + __comment("WallTop=");
            content += "\t" + __comment("WallBottom=");
            content += "\t" + __comment("WallBorder=");
            content += "\t" + __comment("CeilBorder=");
            content += "\t" + __comment("DoorTop=2700");
            content += "\t" + __comment("WindowTop=2700");
            content += "\t" + __comment("WindowBottom=300");
            content += "\t" + __comment("DisplayFilter=");

            content += "\t" + __comment("Wall1");
            content += CssData.wall_html_contents.Distinct().ToTextStr("\r\n");

            content += "</svg>\r\n";

            File.WriteAllText(@"D:\html\wallinfo.html", content);
        }

        static string[] _groupTextLines(List<string> srcs, string type, string key)
        {
            string[] ls = srcs.Where(__s => __s.ct_("<" + type)).ToArray();
            string[] _new_datas = ls.Select(__s => __s.Trim().filter("</>").First().Replace("' ","'| ")).ToArray();
            string[] clrs = _new_datas.Select(__s => __s._prop(key)).Distinct().ToArray();

            List<string> res = new List<string>();

            foreach(string clr in clrs)
            {
                res.Add(clr.et_() ? "\t<g>" : "\t<g " + key + "=" + clr + ">");

                for(int i = 0; i < ls.Length; i++)
                    if(_new_datas[i]._prop(key) == clr)
                    {
                        res.Add("\t\t" + ls[i].Replace(" " + key + "=" + clr, ""));
                    }

                res.Add("\t</g>");
            }

            return res.ToArray();
        }

        public static void WriteHtml(cReadData _css, int _w, int _h, string table_data)
        {
            CssData = _css;
            W = _w;
            H = _h;

            File.WriteAllText(@"D:\html\plan_html.html",
                cReadData.DefaultHtmlCss(CssData.drawing_scale)

                + "<style>\r\n"
                + CssData.HtmlCssList.OrderBy(s => s).ToTextStr("\r\n") 
                + CssData.StyleList.OrderBy(s => s._firstPropName())
                    .Select(s => s._firstPropName() + "\r\n{" + s._firstProp() + "\r\n}\r\n").ToTextStr("\r\n")
                + "</style>\r\n\r\n");

            string[] html_keys = new string[] { "<polyline", "<polygon", "<circle", "<div", "<text" };

            var ls = CssData.html_contents.Distinct().OrderBy(s => DE.NumericArray(0, html_keys.Length - 1)
                .FirstOrDefault(n => s.ct_(html_keys[n])))
                .ThenBy(s => s.ct_(">") ? _repLessTen(s.Substring(s.IndexOf(">") + 1)) : "")
                .ToList();

            Contents = new List<string> { String.Format("<svg width='{0}' height='{1}' viewBox = '{2} -100 {0} {1}'>", W, H * 2, - 100)};

            //Contents.AddRange(ls.Where(__s => !__s.ct_("<text")));
            Contents.AddRange(_groupTextLines(ls,"polyline","style"));
            Contents.AddRange(_groupTextLines(ls,"polygon","style"));
            Contents.AddRange(_groupTextLines(ls,"circle","style"));
            Contents.Add("<g font-size='" + CssData.drawing_title_size * 0.1 + "em' text-anchor ='middle' dominant-baseline='central'>");
            Contents.AddRange(_groupTextLines(ls,"text","fill"));
            Contents.Add("</g>");
            Contents.Add("\n");

            Contents.Add("</svg>");
            Contents.Add("\n");

            File.AppendAllText(@"D:\html\plan_html.html",
                 "<div class='split left'>\r\n" + "<div class='centered'>\r\n"
                + Contents.ToTextStr("\r\n") 
                + "\r\n</div>\r\n</div>\r\n"
                + table_data);

            __save_wall_html();
        }
    }
}